package com.obomprogramador.glplaysphere

open class Element {
    open fun draw(program: Int,
                  projectionMatrix: FloatArray,
                  modelViewMatrix: FloatArray,
                  normalMatrix: FloatArray
                    ) {}
}