package com.obomprogramador.glplaysphere

import android.content.ContentValues.TAG
import android.opengl.GLES20
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.util.*
import kotlin.math.cos
import kotlin.math.sin


class Sphere(private val cor: IntArray, private val raio: Int) : Element() {
    private val vertexPositionData = mutableListOf<Float>()
    private val normalData = mutableListOf<Float>()
    private val indexData = mutableListOf<Int>()
    private val vertexColors = mutableListOf<Float>()
    private lateinit var vertexBuffer: FloatBuffer
    private lateinit var normaisBuffer: FloatBuffer
    private lateinit var indexBuffer: IntBuffer
    private lateinit var coresBuffer: FloatBuffer
    val latitudeBands = 20
    val longitudeBands = 20

    fun generate() {
        // Calcular vértices e normais:
        for (latNumber in 0..latitudeBands) {
            val theta = latNumber * Math.PI / latitudeBands
            val sinTheta = sin(theta)
            val cosTheta = cos(theta)
            for (longNumber in 0..longitudeBands) {
                val phi = longNumber * 2 * Math.PI / longitudeBands
                val sinPhi = sin(phi)
                val cosPhi = cos(phi)
                val x = cosPhi * sinTheta
                var y = cosTheta
                val z = sinPhi * sinTheta
                val u = 1 - longNumber / longitudeBands
                val v = 1 - latNumber / latitudeBands
                normalData.add(x.toFloat())
                normalData.add(y.toFloat())
                normalData.add(z.toFloat())
                vertexPositionData.add((raio * x).toFloat())
                vertexPositionData.add((raio * y).toFloat())
                vertexPositionData.add((raio * z).toFloat())
                // Cor da esfera:
                vertexColors.add(cor[0].toFloat())
                vertexColors.add(cor[1].toFloat())
                vertexColors.add(cor[2].toFloat())
                vertexColors.add(cor[3].toFloat())
            }
        }
        // Calcular índices dos triângulos de cada face:
        for (latNumber in 0 until latitudeBands) {
            for (longNumber in 0 until longitudeBands) {
                val first = (latNumber * (longitudeBands + 1)) + longNumber
                val second = first + longitudeBands + 1
                indexData.add(first)
                indexData.add(second)
                indexData.add(first + 1)
                indexData.add(second)
                indexData.add(second + 1)
                indexData.add(first + 1)
            }
        }

        // Inicializa os buffers do elemento no GLES
        setupGL()
    }

    fun setupGL() {
        vertexBuffer =
            ByteBuffer.allocateDirect( // (# of coordinate values * 4 bytes per float)
                vertexPositionData.size * 4
            ).run {
                order(ByteOrder.nativeOrder())
                asFloatBuffer().apply {
                    put(vertexPositionData.toFloatArray())
                    position(0)
                }
            }

        normaisBuffer =
            ByteBuffer.allocateDirect( // (# of coordinate values * 4 bytes per float)
                normalData.size * 4
            ).run {
                order(ByteOrder.nativeOrder())
                asFloatBuffer().apply {
                    put(normalData.toFloatArray())
                    position(0)
                }
            }

        indexBuffer =
            ByteBuffer.allocateDirect( // (# of coordinate values * 4 bytes per int)
                indexData.size * 4
            ).run {
                order(ByteOrder.nativeOrder())
                asIntBuffer().apply {
                    put(indexData.toIntArray())
                    position(0)
                }
            }

        coresBuffer =
            ByteBuffer.allocateDirect( // (# of coordinate values * 4 bytes per float)
                vertexColors.size * 4
            ).run {
                order(ByteOrder.nativeOrder())
                asFloatBuffer().apply {
                    put(vertexColors.toFloatArray())
                    position(0)
                }
            }
    }

    private fun checkGlError(op: String) {
        var error: Int
        while (GLES20.glGetError().also { error = it } != GLES20.GL_NO_ERROR) {
            Log.e(TAG, "$op: glError $error")
            throw RuntimeException("$op: glError $error")
        }
    }

    override fun draw(program: Int,
                      projectionMatrix: FloatArray,
                      modelViewMatrix: FloatArray,
                      normalMatrix: FloatArray
                    ) {

        GLES20.glUseProgram(program)

        // Vamos criar VOBs (Vertex Object Buffers, na GPU) e mover os dados para a memória controlada por ela:

        val buffers = IntArray(4)
        GLES20.glGenBuffers(4, buffers, 0)
        checkGlError("glGenBuffers 1")

        // VOB de vértices
        var handlerVertex = buffers[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerVertex);
        checkGlError("glBindBuffer 1");
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER,
            vertexPositionData.size * 4,
            vertexBuffer,
            GLES20.GL_STATIC_DRAW);
        checkGlError("glBufferData 1")

        // VOB de normais
        var handlerNormais = buffers[1]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerNormais);
        checkGlError("glBindBuffer 2");
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER,
            normalData.size * 4,
            normaisBuffer,
            GLES20.GL_STATIC_DRAW);
        checkGlError("glBufferData 2")

        // VOB de cores
        var handlerCores = buffers[2]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerCores);
        checkGlError("glBindBuffer 3")
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER,
            vertexColors.size * 4,
            coresBuffer,
            GLES20.GL_STATIC_DRAW);
        checkGlError("glBufferData 3")

        // VOB de índices
        var handlerIndex = buffers[3]
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER,handlerIndex);
        checkGlError("glBindBuffer 4");
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER,
            indexData.size * 4,
            indexBuffer,
            GLES20.GL_STATIC_DRAW);
        checkGlError("glBufferData 4")

        // Obtém handlers para os atributos do programa GLSL (Shaders)
        var mPositionHandle = GLES20.glGetAttribLocation(program, "aVertexPosition")
        checkGlError("glGetAttribLocation aPosition")
        if (mPositionHandle == -1) {
            throw RuntimeException("não localizei o atributo aVertexPosition")
        }

        var mColorHandle = GLES20.glGetAttribLocation(program, "aVertexColor")
        checkGlError("glGetAttribLocation aVertexColor")
        if (mColorHandle == -1) {
            throw RuntimeException("não localizei o atributo aVertexColor")
        }

        var mNormalHandle = GLES20.glGetAttribLocation(program, "aVertexNormal")
        checkGlError("glGetAttribLocation aVertexNormal")
        if (mNormalHandle == -1) {
            throw RuntimeException("não localizei o atributo aVertexNormal")
        }

        // Obtém handlers para os "uniforms" do programa GLSL
        var mMVMatrixHandle = GLES20.glGetUniformLocation(program, "uMVMatrix")
        checkGlError("glGetUniformLocation mMVMatrixHandle")
        if (mMVMatrixHandle == -1) {
            throw RuntimeException("não localizei o atributo mMVMatrixHandle")
        }

        var mPMatrixHandle = GLES20.glGetUniformLocation(program, "uPMatrix")
        checkGlError("glGetUniformLocation mPMatrixHandle")
        if (mPMatrixHandle == -1) {
            throw RuntimeException("não localizei o atributo mPMatrixHandle")
        }

        var mNormalMatrixHandle = GLES20.glGetUniformLocation(program, "uNormalMatrix")
        checkGlError("glGetUniformLocation mNormalMatrixHandle")
        if (mNormalMatrixHandle == -1) {
            throw RuntimeException("não localizei o atributo mNormalMatrixHandle")
        }

        // Associa os buffers aos handlers do programa
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerVertex)
        GLES20.glVertexAttribPointer(mPositionHandle, 3, GLES20.GL_FLOAT, false,0, 0)
        GLES20.glEnableVertexAttribArray(mPositionHandle);

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerNormais)
        GLES20.glVertexAttribPointer(mNormalHandle, 3, GLES20.GL_FLOAT, false,0, 0)
        GLES20.glEnableVertexAttribArray(mNormalHandle);

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, handlerCores)
        GLES20.glVertexAttribPointer(mColorHandle, 4, GLES20.GL_FLOAT, false,0, 0)
        GLES20.glEnableVertexAttribArray(mColorHandle);

        // Associa as matrizes aos handlers dos "uniforms" do programa
        GLES20.glUniformMatrix4fv(mMVMatrixHandle, 1, false, modelViewMatrix, 0)
        GLES20.glUniformMatrix4fv(mPMatrixHandle, 1, false, projectionMatrix, 0)
        GLES20.glUniformMatrix4fv(mNormalMatrixHandle, 1, false, normalMatrix, 0)

        // Desenha a esfera
        GLES20.glDrawElements(GLES20.GL_LINE_STRIP,indexData.size,GLES20.GL_UNSIGNED_INT,0)
    }

}
