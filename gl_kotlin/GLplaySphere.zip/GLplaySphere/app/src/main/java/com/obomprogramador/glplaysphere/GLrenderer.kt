package com.obomprogramador.glplaysphere

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.DisplayMetrics
import android.view.WindowManager
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10


class MainRenderer(private val context: Context,
                   private val vertexShaderCode: String,
                   private val fragmentShaderCode: String,
                   private val elements: List<Element>) : GLSurfaceView.Renderer {

    var program: Int = 0
    var vertexShader: Int = 0
    var fragmentShader: Int = 0
    var larguraViewPort: Int = 0
    var alturaViewPort: Int = 0
    private val vPMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private var ratio: Float = 0.0F

    override fun onSurfaceCreated(unused: GL10, config: EGLConfig) {

        // Prepare Shaders
        vertexShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER).also { shader ->
            // add the source code to the shader and compile it
            GLES20.glShaderSource(shader, vertexShaderCode)
            GLES20.glCompileShader(shader)
        }

        fragmentShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER).also { shader ->
            // add the source code to the shader and compile it
            GLES20.glShaderSource(shader, fragmentShaderCode)
            GLES20.glCompileShader(shader)
        }

        // Compile and link shaders into a program
        program = GLES20.glCreateProgram().also {

            // add the vertex shader to program
            GLES20.glAttachShader(it, vertexShader)

            // add the fragment shader to program
            GLES20.glAttachShader(it, fragmentShader)

            // creates OpenGL ES program executables
            GLES20.glLinkProgram(it)
        }

        // Set the background frame color
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)

    }

    override fun onDrawFrame(unused: GL10) {
        // Redraw background color
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        Matrix.setIdentityM(projectionMatrix,0)
        Matrix.setIdentityM(viewMatrix,0)

        Matrix.perspectiveM(projectionMatrix,0, 45.0F,ratio,1.0F, 100.0F)

        // Set the camera position (View matrix)
        Matrix.setLookAtM(viewMatrix, 0, 0f, 0f, 10f, 0.0f, 0.0f, -5.0f, 0f, 1.0f, 0.0f)

        // Calculate the projection and view transformation
        Matrix.multiplyMM(vPMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        var normalsMatrix = FloatArray(16)
        Matrix.invertM(normalsMatrix,0,viewMatrix,0)
        Matrix.transposeM(normalsMatrix,0,normalsMatrix,0)

        // Calcula a matrix do modelo
        var angulox = 0.0 // mude os ângulos para mudar a visualização
        var anguloy = 0.0
        var anguloz = 0.0
        var modelMatrix = FloatArray(16)
        var modelViewMatrix = FloatArray(16)
        Matrix.setIdentityM(modelMatrix,0)
        Matrix.translateM(modelMatrix,0,modelMatrix,0,0.0F,0.0F,0.0F)
        Matrix.rotateM(modelMatrix,0,modelMatrix,0,angulox.toFloat(),1.0F,0.0F,0.0F)
        Matrix.rotateM(modelMatrix,0,modelMatrix,0,anguloy.toFloat(),0.0F,1.0F,0.0F)
        Matrix.rotateM(modelMatrix,0,modelMatrix,0,anguloz.toFloat(),0.0F,0.0F,1.0F)
        Matrix.multiplyMM(modelViewMatrix, 0, modelMatrix, 0, viewMatrix, 0)
        for (element in elements) {
            element.draw(program,projectionMatrix,modelViewMatrix,normalsMatrix)
        }
    }

    override fun onSurfaceChanged(unused: GL10, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        ratio = width.toFloat() / height.toFloat()

        // this projection matrix is applied to object coordinates
        // in the onDrawFrame() method
        //Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -10f, 10f, 3f, 7f)
    }
}