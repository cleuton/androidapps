package com.obomprogramador.glplaysphere

import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle

class GlActivity : Activity() {

    private lateinit var gLView: GLSurfaceView
    private val elements = mutableListOf<Element>()

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val esfera = Sphere(intArrayOf(1, 0, 0, 1),2)
        esfera.generate()
        elements.add(esfera)
        gLView = MainView(this, elements)

        setContentView(gLView)
    }
}