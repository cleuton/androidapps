package com.obomprogramador.glplaysphere

import android.content.Context
import android.opengl.GLSurfaceView

class MainView(context: Context,
               elements: List<Element>) : GLSurfaceView(context) {

    private val vertexShaderCode = """
    	attribute vec3 aVertexPosition;
    	attribute vec4 aVertexColor;
    	attribute vec4 aVertexNormal;
	    uniform mat4 uMVMatrix;
    	uniform mat4 uPMatrix;
    	uniform mat4 uNormalMatrix;

    	varying lowp vec4 vColor;
    	
	    void main(void) {
	    
	    	highp vec3 uLightColor = vec3(0.95, 0.97, 0.51);
        	highp vec3 uLightDirection = vec3(0.5, 0.99, 0.99);
        	highp vec3 ambientColor = vec3(0.4, 0.4, 0.4);
	    
    	    gl_Position = uPMatrix * uMVMatrix * vec4(aVertexPosition, 1.0);
    	    vec4 xnormal = uNormalMatrix * aVertexNormal;
    	    float dotNormal = max(dot(uLightDirection, normalize(xnormal.xyz)), 0.0);
    	    vec3 ambient = ambientColor * aVertexColor.rgb;
    	    vColor = vec4((aVertexColor.xyz * dotNormal) + ambient , aVertexColor.a);;
    	}        
    """.trimIndent()

    private val fragmentShaderCode = """
        precision mediump float;
        varying lowp vec4 vColor;
        void main(void) {
            gl_FragColor = vColor;
        }
    """.trimIndent()

    private val renderer: MainRenderer

    init {

        // Create an OpenGL ES 2.0 context
        setEGLContextClientVersion(2)

        renderer = MainRenderer(context, vertexShaderCode,fragmentShaderCode, elements)

        // Set the Renderer for drawing on the GLSurfaceView
        setRenderer(renderer)

        // Render the view only when there is a change in the drawing data
        renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    }
}