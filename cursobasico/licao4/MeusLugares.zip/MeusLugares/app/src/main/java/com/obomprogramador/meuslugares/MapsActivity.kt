package com.obomprogramador.meuslugares

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_maps.*
import java.io.IOException


class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    private fun getAddress(latLng: LatLng): String {
        val geocoder = Geocoder(this)
        val addresses: List<Address>?
        var addressText = ""

        try {
            addresses = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
            if (null != addresses && !addresses.isEmpty()) {
                addressText = addresses[0].getAddressLine(0)
            }
        } catch (e: IOException) {
            Log.e("MapsActivity", e.localizedMessage)
        }

        return addressText
    }

    fun changePrefs(endereco: String, latLng: LatLng) {
        val sharedPreference =  getSharedPreferences("meuslugares", Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        var texto = "${latLng.latitude}:${latLng.longitude}"
        editor.putString(endereco,texto)
        editor.commit()
    }

    fun getPrefs() : List<String>? {
        val mapa = getSharedPreferences("meuslugares", Context.MODE_PRIVATE).all
        val saida = mutableListOf<String>()
        for (entrada in mapa) {
            saida.add("${entrada.key}:${entrada.value}")
        }
        return saida
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val ui = mMap.uiSettings
        ui.isZoomControlsEnabled = true
        val geocoder = Geocoder(this)
        // Add a marker in Sydney and move the camera
        val botafogo = LatLng(-22.9504578,-43.1828463)
        //mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))

        var addressText = getAddress(botafogo)
        Log.i("Endereco",addressText)

        mMap.moveCamera(CameraUpdateFactory.newLatLng(botafogo))
        mMap.moveCamera(CameraUpdateFactory.zoomTo(15.0F))

        mMap.setOnMapClickListener { latlong ->
            Toast.makeText(this,getAddress(latlong),Toast.LENGTH_LONG).show()
        }

        mMap.setOnMapLongClickListener {
            val endereco = getAddress(it)
            mMap.addMarker(MarkerOptions().position(it).title(endereco))
            Toast.makeText(this,"Adicionando: ${endereco}",Toast.LENGTH_LONG).show()
            changePrefs(endereco,it)
        }

        floatingActionButton.setOnClickListener {
            val lista = getPrefs()
            if ((lista?.size ?: 0) == 0) {
                Toast.makeText(this, "Não há preferidos ainda!", Toast.LENGTH_SHORT).show()
            }
            else {
                val menu = PopupMenu(this, floatingActionButton)
                if (lista != null) {
                    for (texto in lista) {
                        menu.menu.add(texto)
                        menu.setOnMenuItemClickListener {
                            val litens = it.title.split(":")
                            val posic = LatLng(litens[1].toDouble(),litens[2].toDouble())
                            mMap.addMarker(MarkerOptions().position(posic).title(litens[0]))
                            mMap.moveCamera(CameraUpdateFactory.newLatLng(posic))
                            mMap.moveCamera(CameraUpdateFactory.zoomTo(15.0F))
                            true
                        }
                    }
                }
                menu.show()
            }
        }
    }

}
