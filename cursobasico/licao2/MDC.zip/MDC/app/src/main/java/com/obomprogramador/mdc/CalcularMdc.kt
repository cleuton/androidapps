package com.obomprogramador.mdc

fun calcularMdc (primeiro: Long, segundo: Long) : Long {
    val maior = maxOf(primeiro, segundo)
    val primos = gerarPrimos(maior)
    val fatores = mutableListOf<Long>()
    var a = primeiro
    var b = segundo
    fatores.add(1L)
    for (primo in primos) {
        if ((a % primo != 0L) ||
            (b  % primo != 0L)) {
            break
        }
        a /= primo
        b /= primo
        fatores.add(primo)
    }
    return fatores.reduce { acc, i ->  acc * i }
}